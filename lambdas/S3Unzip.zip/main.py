import boto3, mimetypes, zipfile
from io import BytesIO
from pathlib import Path

def downloadS3(bucketName: str, zipFileKey: str):
    s3 = boto3.client('s3')
    response = s3.get_object(Bucket=bucketName, Key=zipFileKey)
    return BytesIO(response['Body'].read())

def extractZip(zipData: str, extractTo: str):
    with zipfile.ZipFile(zipData, 'r') as zipRef:
        zipRef.extractall(extractTo)

def uploadS3(s3Client: str, filePath: str, bucketName, s3Key, extraArgs):
    s3Client.upload_file(filePath, bucketName, s3Key, ExtraArgs=extraArgs)
    print(f"Upload {filePath} como {s3Key}, seguinte content-type: {extraArgs.get('ContentType')}")

def cleanDirectory(directory: str):
    for item in directory.iterdir():
        if item.is_dir():
            cleanDirectory(item)
        else:
            item.unlink()
    directory.rmdir()

def cleanBucket(s3Client: str, bucketName: str):
    print("Listing objects in bucket")
    response = s3Client.list_objects_v2(Bucket=bucketName)
    objects = response.get('Contents', [])
    print("Deleting objects in bucket (except for 'uploads' folder)")
    for obj in objects:
        if not obj['Key'].startswith('uploads/'):
            s3Client.delete_object(Bucket=bucketName, Key=obj['Key'])
            print(f"Deleted object {obj['Key']}")

def main(event, context):
    try:
        bucketName = event['Records'][0]['s3']['bucket']['name']
        zipFileKey = event['Records'][0]['s3']['object']['key']
        tempDir = Path('/tmp/extracted_files')
        tempDir.mkdir(parents=True, exist_ok=True)
        print(f"Download de pacote {zipFileKey} feito do bucket: {bucketName}")
        zipData = downloadS3(bucketName, zipFileKey)
        print("Inicio da extração")
        extractZip(zipData, tempDir)
        print("Fim da extração")
        s3Client = boto3.client('s3')
        # Limpeza do bucket
        cleanBucket(s3Client, bucketName)

        for filePath in tempDir.rglob('*'):
            if filePath.is_file():
                s3Key = str(filePath.relative_to(tempDir))
                contentType = mimetypes.guess_type(filePath)[0] or 'application/octet-stream'
                extraArgs = {'ContentType': contentType}
                uploadS3(s3Client, str(filePath), bucketName, s3Key, extraArgs)

        cleanDirectory(tempDir)
        print("limpeza de pasta temporaria feita")
        return {
            'statusCode': 200,
            'body': 'Arquivos inseridos com sucesso'
        }
    except Exception as error:
        print(f"An error occurred: {str(error)}")
        return {
            'statusCode': 500,
            'body': f'An error occurred: {str(error)}'
        }
